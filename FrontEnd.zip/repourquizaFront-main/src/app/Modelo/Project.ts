export class Project{
    id!:number;
    author!:String;
    year!:String;
    area!: String;
    title!:String;
    project!: String;
    created!: Date;
    description!: String;
}
