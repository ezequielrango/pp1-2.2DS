package com.repourquiza.repourquiza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RepourquizaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RepourquizaApplication.class, args);
	}

}
