package com.repourquiza.repourquiza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RepourquizaApplicationTests {

	@Test
	void contextLoads() {
	}

}
