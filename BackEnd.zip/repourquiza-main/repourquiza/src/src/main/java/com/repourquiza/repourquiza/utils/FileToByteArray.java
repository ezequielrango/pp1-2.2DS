package com.repourquiza.repourquiza.utils;

public class FileToByteArray {
	
}
